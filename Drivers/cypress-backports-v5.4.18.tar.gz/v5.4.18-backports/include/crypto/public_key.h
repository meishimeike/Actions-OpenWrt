/* Automatically created during backport process */
#ifndef CPTCFG_BPAUTO_PUBLIC_KEY
#include_next <crypto/public_key.h>
#else
#include <crypto/backport-public_key.h>
#endif /* CPTCFG_BPAUTO_PUBLIC_KEY */
